# 我的手写笔记（my_handnote）

拍照 / 相册多选 → 自动裁边去阴影 → 手写 OCR → 规则排版 → 导出可搜索 PDF。

这是文章里的可运行骨架。**主链路（拍照 → 识别 → 排版 → 导出 PDF）已接通**，
原生 OCR 与字体资源需要按下面两步补上才能真正跑出识别结果。

## 一、环境

- Flutter 3.22+（Dart 3.3+）
- Android：minSdk 24，compileSdk 34；iOS：12.0+
- Xcode（打 iOS 包时需要）

## 二、跑起来

```bash
cd handnote_skeleton
flutter pub get
flutter run
```

首次运行如果 `opencv_dart` 编译失败，先执行：

```bash
flutter clean
flutter pub get
```

## 三、必做两步

### 1. 放中文字体（不嵌入字体会乱码）

```bash
mkdir -p assets/fonts
# 从 Google Fonts 下载 Noto Sans SC Regular，重命名后放入
# https://fonts.google.com/noto/specimen/Noto+Sans+SC
# 文件名必须是 NotoSansSC-Regular.ttf
```

字体文件约 10 MB，建议构建时用 `--split-debug-info` 之外的方式做子集化，见文档第 6.3 节。

### 2. 接 OCR

`lib/services/ocr_service.dart` 通过 `MethodChannel('handnote/ocr')` 调原生识别。
两种做法：

- **省事**：接入社区 PaddleOCR 插件（搜 `flutter_paddle_ocr`），在插件内部或
  自己的 `MethodChannel` 里把结果转成 `[{text, confidence, x, y, w, h}]`。
- **可控**：自己接 Paddle-Lite，模型用 `paddle_lite_opt` 转成 `.nb`，
  det / cls / rec 三个模型放 `android/app/src/main/assets/`，
  代码见 `android_ocr_sample.kt`。

原生没接上时，App 不会崩：识别返回空列表，结果页允许用户手写补录 ——
这也是产品上"不追求 100% 自动"的兜底设计。

## 四、切换云端 OCR（可选）

```dart
final pipeline = NotePipeline(
  ocr: OcrService(cloud: const CloudOcrConfig(
    apiKey: '你的 API_KEY',
    secretKey: '你的 SECRET_KEY',
  )),
);
await pipeline.run(paths, engine: OcrEngine.cloud);
```

## 五、打包

```bash
# Android 分架构包
flutter build apk --release --split-per-abi

# Google Play 用 AAB
flutter build appbundle --release

# iOS（需 macOS + 证书）
flutter build ipa --release
```

## 六、目录

```
lib/
  models/models.dart              数据模型
  data/app_database.dart          SQLite 笔记库 + 检索
  services/capture_service.dart   拍照 / 相册多选
  services/preprocess_service.dart 透视矫正、去阴影、CLAHE
  services/ocr_service.dart       本地 PaddleOCR + 云端兜底
  services/layout_service.dart    标题/正文/列表/待办 结构识别
  services/pdf_service.dart       矢量 PDF 生成
  pipeline/note_pipeline.dart     主链路编排
  pages/review_page.dart          逐行校对
  pages/export_sheet.dart         导出参数面板
  main.dart                       笔记库首页
```

## 七、已知限制

- 公式只做标记与保留原样，不重建 LaTeX（P2）
- 表格只保留行结构，不还原单元格（P2）
- 检索用 LIKE，笔记过万后建议换 FTS5(trigram)
- 手写连笔较重的页面，本地识别置信度普遍低于 0.6，产品上用"低置信度高亮"提示用户重点校对
