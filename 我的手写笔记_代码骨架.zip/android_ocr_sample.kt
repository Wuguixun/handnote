package com.example.handnote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.annotation.NonNull
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import kotlin.concurrent.thread

/**
 * 原生侧 OCR 通道：MethodChannel("handnote/ocr") -> method "recognize"
 * 入参：path（预处理后的图片路径）, language（"ch"）
 * 出参：List<Map>{ text, confidence, x, y, w, h }（像素坐标）
 *
 * 实现方式二选一：
 * A. 直接复用社区插件里的 PaddleOCR 引擎类（推荐，先把链路跑通）
 * B. 自己接 Paddle-Lite：把 det/cls/rec 三个 .nb 模型放 assets，
 *    用 PaddlePredictor 依次跑检测 -> 方向分类 -> 识别
 *
 * 下面是 B 的结构骨架，OcrCore 需要替换成真实推理实现。
 */
class OcrPlugin : FlutterPlugin, MethodChannel.MethodCallHandler {

    private lateinit var channel: MethodChannel
    private lateinit var appContext: Context
    private var ocrCore: OcrCore? = null

    override fun onAttachedToEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        appContext = binding.applicationContext
        channel = MethodChannel(binding.binaryMessenger, "handnote/ocr")
        channel.setMethodCallHandler(this)
        // 首次加载模型较慢（约 300~800ms），放在后台线程初始化，避免首帧卡顿
        thread { ocrCore = OcrCore(appContext) }
    }

    override fun onDetachedFromEngine(@NonNull binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
        ocrCore?.release()
    }

    override fun onMethodCall(@NonNull call: MethodCall, @NonNull result: MethodChannel.Result) {
        when (call.method) {
            "recognize" -> {
                val path = call.argument<String>("path")
                if (path == null) {
                    result.error("BAD_ARGS", "path is null", null)
                    return
                }
                thread {
                    try {
                        val bitmap = BitmapFactory.decodeFile(path)
                            ?: run {
                                result.error("DECODE_FAIL", "decode failed: $path", null)
                                return@thread
                            }
                        val core = ocrCore ?: OcrCore(appContext).also { ocrCore = it }
                        val lines = core.recognize(bitmap)
                        // 回调必须回主线程
                        android.os.Handler(android.os.Looper.getMainLooper())
                            .post { result.success(lines) }
                        bitmap.recycle()
                    } catch (e: Exception) {
                        android.os.Handler(android.os.Looper.getMainLooper())
                            .post { result.error("OCR_FAIL", e.message, null) }
                    }
                }
            }
            "warmUp" -> {
                ocrCore?.warmUp()
                result.success(true)
            }
            else -> result.notImplemented()
        }
    }
}

/**
 * 推理封装。真实实现里三步：
 * 1) det：DB 检测得到文本行四点框
 * 2) cls：0/180 度方向分类，把倒置行转正
 * 3) rec：CRNN + CTC 解码，得到文字与置信度
 * 输出保持与 Dart 侧约定的字段名一致。
 */
class OcrCore(private val context: Context) {

    private var det: Long = 0
    private var cls: Long = 0
    private var rec: Long = 0

    fun warmUp() {
        // 触发一次空图推理，避免用户第一次点"识别"时等太久
    }

    fun recognize(bitmap: Bitmap): List<Map<String, Any>> {
        // TODO: 用 Paddle-Lite 加载 assets 下的 det/cls/rec .nb 模型并推理
        // 这里返回空列表，Dart 侧会走"允许手动补录"的兜底分支
        val out = mutableListOf<Map<String, Any>>()
        return out
    }

    fun release() {
        // det/cls/rec predictor 释放
    }
}

/**
 * AndroidManifest.xml 需要：
 * <uses-permission android:name="android.permission.CAMERA" />
 * <uses-feature android:name="android.hardware.camera" android:required="false" />
 *
 * iOS Info.plist 需要：
 * NSCameraUsageDescription、NSPhotoLibraryUsageDescription
 * 以及 Podfile 里 platform :ios, '12.0'
 */
